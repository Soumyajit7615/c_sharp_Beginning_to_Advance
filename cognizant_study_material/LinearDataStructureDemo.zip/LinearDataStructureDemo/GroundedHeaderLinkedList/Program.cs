﻿using System;

namespace GroundedHeaderLinkedList
{
    // Structure of the list
    public class link
    {
        public int info;

        // Pointer to the next node
        public link next;
    };
    class Program
    {// Empty List
        static link start = null;

        // Function to create header of the
        // header linked list
        static link create_header_list(int data)
        {

            // Create a new node
            link new_node, node;
            new_node = new link();
            new_node.info = data;
            new_node.next = null;

            // If it is the first node
            if (start == null)
            {

                // Initialize the start
                start = new link();
                start.next = new_node;
            }
            else
            {

                // Insert the node in the end
                node = start;
                while (node.next != null)
                {
                    node = node.next;
                }
                node.next = new_node;
            }
            return start;
        }

        // Function to display the
        // header linked list
        static link display()
        {
            link node;
            node = start;
            node = node.next;

            // Traverse until node is
            // not null
            while (node != null)
            {

                // Print the data
                Console.Write("{0} ", node.info);
                node = node.next;
            }
            Console.Write("\n");

            // Return the start pointer
            return start;
        }

        // Driver Code
        public static void Main(String[] args)
        {
            // Create the list
            create_header_list(11);
            create_header_list(12);
            create_header_list(13);

            // Print the list
            Console.Write("List After inserting"
                  + " 3 elements:\n");
            display();
            create_header_list(14);
            create_header_list(15);

            // Print the list
            Console.Write("List After inserting"
                  + " 2 more elements:\n");
            display();

        }
    }
}
