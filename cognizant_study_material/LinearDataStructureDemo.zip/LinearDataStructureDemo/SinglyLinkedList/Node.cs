﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SinglyLinkedList
{
    // Structure of Node
    public class Node
    {
        public int data;

        // Pointer to next node in LL
        public Node next;
    };
}
