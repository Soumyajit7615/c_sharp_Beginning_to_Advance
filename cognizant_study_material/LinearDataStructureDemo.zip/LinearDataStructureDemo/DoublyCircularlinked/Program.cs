﻿using System;

namespace DoublyCircularlinked
{
    // Structure of a Node
    public class Node
    {
        public int data;

        // Pointer to next node in DCLL
        public Node next;

        // Pointer to the previous node in DCLL
        public Node prev;
    };
    class Program
    {
        // Start with the empty list
        static Node start = null;

        // Function to insert Node at
        // the beginning of the List
        static void insertBegin(
                         int value)
        {
            Node new_node = new Node();

            // If the list is empty
            if (start == null)
            {

                new_node.data = value;
                new_node.next
                    = new_node.prev = new_node;
                start = new_node;
                return;
            }

            // Pointer points to last Node
            Node last = (start).prev;

            // Inserting the data
            new_node.data = value;

            // Update the previous and
            // next of new node
            new_node.next = start;
            new_node.prev = last;

            // Update next and previous
            // pointers of start & last
            last.next = (start).prev
                = new_node;

            // Update start pointer
            start = new_node;
        }

        // Function to traverse the circular
        // doubly linked list
        static void display()
        {
            Node temp = start;

            Console.Write("\nTraversal in"
                   + " forward direction \n");
            while (temp.next != start)
            {
                Console.Write(temp.data + " ");
                temp = temp.next;
            }
            Console.Write(temp.data + " ");

            Console.Write("\nTraversal in "
                + "reverse direction \n");
            Node last = start.prev;
            temp = last;

            while (temp.prev != last)
            {

                // Print the data
                Console.Write(temp.data + " ");
                temp = temp.prev;
            }
            Console.Write(temp.data + " ");
        }

        static void Main(string[] args)
        {
            // Insert 5
            // So linked list becomes 5.null
            insertBegin(5);

            // Insert 4 at the beginning
            // So linked list becomes 4.5
            insertBegin(4);

            // Insert 7 at the end
            // So linked list becomes 7.4.5
            insertBegin(7);

            Console.Write("Created circular doubly"
                  + " linked list is: ");
            display();
        }
    }

}
