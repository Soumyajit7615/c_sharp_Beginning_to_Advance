function SomeFunction() {
    alert("Hello World!!");
}
var b1 =document.getElementById("btn");
b1.onclick = SomeFunction;