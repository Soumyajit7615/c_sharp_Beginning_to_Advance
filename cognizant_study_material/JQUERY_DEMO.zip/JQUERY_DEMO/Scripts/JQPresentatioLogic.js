$(document).ready(function () {
    $(".btn").click(function () {
        alert("HELLO WORLD FROM JQUERY");
    }
    )
})