﻿using System;
using System.Collections.Generic;
using System.Collections;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GenericsStuff
{
    class GenericsCollectionDemo
    {
        static void Main(string[] args)
        {
            ArrayList Alist = new ArrayList();
            Alist.Add(10);
            Alist.Add(20);
            //Alist.Add("Thirty");
            Alist.Add(40);
            Console.WriteLine("List of Elements :");
            foreach (int itn in Alist)
            {
                Console.WriteLine(itn);
            }


            List<int> IntList = new List<int>();
            IntList.Add(10);
            IntList.Add(20);
            //IntList.Add("Thirty");// Cannot convert from 'string' to 'int'   
            IntList.Add(30);
            IntList.Add(40);
            foreach (int n in IntList)
            {
                Console.WriteLine(n);
            }

            Dictionary<string, string> Dict = new Dictionary<string, string>();
            Dict.Add(".txt", "Notepad.exe");
            Dict.Add(".rtf", "Wordpad.exe");
            Dict.Add(".doc", "Winword.exe");
            Dict.Add(".bmp", "mspaint.exe");
            Dict.Add("controlpanel", "control.exe");
            Dict.Add("appwiz.cpl", "add and remove program");
            Dict.Add("chrome", "chrome browser");
            Dict.Add("powerpoint", "powerpnt.exe");
            Dict.Add("Visual Studio", "devenv.exe");
            Dict.Add("VS Code", "Code.exe");
            Dict.Add("Services", "service.msc");
            Console.WriteLine("Key Value : {0}", Dict[".txt"]);
            //Dict[".txt"] = "Hello Hello";
            //Console.WriteLine("Key Value : {0}", Dict[".txt"]);

            Console.WriteLine("By using foreach :");
            foreach (KeyValuePair<string, string> kvp in Dict)
            {
                Console.WriteLine("Key :{0} and Value :{1}", kvp.Key, kvp.Value);

            }

            Console.WriteLine("Keys from Dictionary :");
            foreach (string k in Dict.Keys)
            {
                Console.WriteLine(k);
            }

            Console.WriteLine("Values from Dictionary :");
            foreach (string v in Dict.Values)
            {
                Console.WriteLine(v);
            }

            Dictionary<int, string> EmployeeList = new Dictionary<int, string>();
            EmployeeList.Add(12345, "ABHISHEK");
            EmployeeList.Add(12346, "JANANI");
            EmployeeList.Add(12347, "CHANDRAJEET");
            EmployeeList.Add(12348, "SMRITI");

            Console.WriteLine("Keys from Dictionary :");
            foreach (int k in EmployeeList.Keys)
            {
                Console.WriteLine(k);
            }

            Console.WriteLine("Values from Dictionary :");
            foreach (string v in EmployeeList.Values)
            {
                Console.WriteLine(v);
            }

            IDictionaryEnumerator IDen = Dict.GetEnumerator();

            while (IDen.MoveNext())
            {
                Console.WriteLine($" KEYS : {IDen.Key} VALUES :  {IDen.Value} ");

            }
           

            
           

            //getch
            //getche - echo
        }
    }
}
