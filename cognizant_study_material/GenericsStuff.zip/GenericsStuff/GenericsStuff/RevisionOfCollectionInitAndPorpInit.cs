﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GenericsStuff
{
    class Customer
    {
        public Customer() { }
        public Customer(int custId, string custName, int deptId)
        {
            this.custId = custId;
            this.custName = custName;
            this.deptId = deptId;
        }
        public void GetDetails()
        {
            Console.WriteLine($"{custId} {custName} {deptId} {Dessignation} {JoinigDate:dd/MM/yyyy hh:mm:ss tt}");


        }
        public void SetCustomerDetails(int custId, string custName, int deptId)
        {
            this.custId = custId;
            this.custName = custName;
            this.deptId = deptId;
        }

        private string custName;
        public string CustName
        {
            get { return custName; }
            set { custName = value; }
        }

        private int custId;

        public int CustId
        {
            get { return custId; }
            set { custId = value; }
        }


        private int deptId;

        public int DeptId
        {
            get { return deptId; }
            set { deptId = value; }
        }

        public string Dessignation { get; set; }
        public DateTime JoinigDate { get; set; } = DateTime.Now;

    }


    class RevisionOfCollectionInitAndPorpInit
    {
        static void Main(string[] args)
        {
            //LHS = RHS
            Customer customer = new Customer(1001, "Kishkendu", 1234);
            int[] MyIntArr = { 1, 2, 4, 5, 6, 7, 8 };
            int[,,] My3DimArray = new int[2, 3, 2]
            {
                { {1,2},{1,2},{1,2}},
                { {1,2},{1,2},{1,2}}
            };
            //OBJECT INITIALIZER IN C# 3.0

            Customer CustObj = new Customer()
            {
                CustName = "Abhishek Sharma",
                CustId = 10001,
                DeptId = 101
            };

            CustObj.GetDetails();

            //List<Customer> customers = new List<Customer>();
            //Customer CustObj1 = new Customer()
            //{
            //    CustName = "Sneha Dey",
            //    CustId = 10002,
            //    DeptId = 101
            //};
            //customers.Add(CustObj1);
            //customers.Add(CustObj);
            List<Customer> customers = new List<Customer>()
            {
                new Customer()
            {
                CustName = "Abhishek Sharma",
                CustId  = 10001,
                DeptId = 101
            },
                new Customer()
            {
                CustName = "Sneha Dey",
                CustId = 10002,
                DeptId = 101
            }



        };









        }

    }
}
