﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GenericsStuff
{
    class ClsProduct
    {
        public int ProdCode { get; set; }
        public string ProdName { get; set; }
        public double ProdPrice { get; set; }
    }
    class CollectionInitializerDemo
    {
        static void Main(string[] args)
        {
            int[] intArr = new int[6];
            intArr[0] = 1;
            int[] intArrr = new int[6] { 1, 2, 3, 4, 5, 6 };
            int[] intAr = { 1, 2, 3, 4, 5, 6 };
            //List<ClsProduct> products = new List<ClsProduct>();
            //ClsProduct product = new ClsProduct()
            //{
            //    ProdCode = 1001,
            //    ProdName = "Laptop",
            //    ProdPrice = 25000
            //};
            //products.Add(product);
            //product = new ClsProduct()
            //{
            //    ProdCode = 1002,
            //    ProdName = "HDD",
            //    ProdPrice = 4500
            //};
            //products.Add(product);

            //  C# 3.0  COLLECTION INITIALIZER
            List<ClsProduct> products = new List<ClsProduct>() {
              new ClsProduct(){ProdCode = 1001,ProdName = "Laptop",ProdPrice = 25000},
              new ClsProduct(){ProdCode = 1002, ProdName = "HDD",ProdPrice = 4500},
              new ClsProduct(){ProdCode = 1003, ProdName = "Speakers",ProdPrice = 30000}
            };
            foreach (ClsProduct prod in products)
            {
                if (prod.ProdPrice > 5000 && prod.ProdName.Contains("S"))
                {
                    Console.WriteLine($"{prod.ProdCode}  {prod.ProdName} {prod.ProdPrice}");
                }

            }

        }
    }
}
