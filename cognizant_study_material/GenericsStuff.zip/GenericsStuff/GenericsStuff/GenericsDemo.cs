﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GenericsStuff
{
    class GenericsDemo
    {
        static void SwapNumber(ref int x, ref int y)
        {
            int temp;
            temp = x;
            x = y;
            y = temp;

        }
        static void GenSwap<T>(ref T x, ref T y)
        {
            T temp;
            temp = x;
            x = y;
            y = temp;

        }
        static void GenDisplay<NUMBER, ALPHANUMERIC>(NUMBER n, ALPHANUMERIC an)
        {

            Console.WriteLine($"Passing Number {n} : {n.GetType()} and Value {an} : {an.GetType()}");
        }
        static void GenDada<NANDI>(NANDI p)
        {
            Console.WriteLine($"The value {p} and type {p.GetType()}");

        }

        static void Main(string[] args)
        {
            int x = 10, y = 20;
            string str1 = "Flakes", str2 = "Corn";
            Console.WriteLine("Before swaping  :X {0}  and Y  :{1}", x, y);
            SwapNumber(ref x, ref y);
            Console.WriteLine("After swaping : X :{0} and Y : {1}", x, y);
           
            Console.WriteLine("Before swaping  :X {0}  and Y  :{1}", x, y);
            GenSwap<int>(ref x, ref y);
            Console.WriteLine("After swaping : X :{0} and Y : {1}", x, y);
           
            Console.WriteLine("Before swaping  :str1 {0}  and str2  :{1}", str1, str2);
            GenSwap<string>(ref str1, ref str2);
            Console.WriteLine("After swaping :  :str1 {0}  and str2  :{1}", str1, str2);

            GenDisplay<decimal, string>(1234.56m, "Abhishek");

            GenDada<string>("I am string");
            GenDada<int>(1234);
            GenDada<decimal>(1234.56m);
            GenDada<float>(1234.56f);

        }
    }
}
