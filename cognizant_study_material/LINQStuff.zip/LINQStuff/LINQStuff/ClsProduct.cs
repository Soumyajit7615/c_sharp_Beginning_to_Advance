﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LINQStuff
{
    class ClsProduct
    {
        public int ProdCode { get; set; }
        public string ProdName { get; set; }
        public float ProdPrice { get; set; }

    }
}
