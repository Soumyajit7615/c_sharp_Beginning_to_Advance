﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Linq;

namespace LINQStuff
{
    class LINQ_to_XMLDemo
    {
        static void Main(string[] args)
        {
            XDocument doc = XDocument.Load("Person.xml");
            var Info = from d in doc.Element("PersonInfo").Elements("Person")
                       select new
                       {
                           ID = d.Element("ID").Value,
                           Name = d.Element("Name").Value,
                           Age = d.Element("Age").Value
                       };
            Console.WriteLine("By LINQ:");
            foreach (var p in Info)
            {
                Console.WriteLine("\n {0} {1} {2}", p.ID, p.Name, p.Age);

            }
            Console.WriteLine("By QUERY EXPRESSION OR LAMBDA EPRESSION:");
            var xmlinfo = doc.Element("PersonInfo").Elements("Person").Select(x =>
             new
             {
                 ID = x.Element("ID").Value,
                 Name = x.Element("Name").Value,
                 Age = x.Element("Age").Value
             });

            foreach (var p in xmlinfo)
            {
                Console.WriteLine("\n {0} {1} {2}", p.ID, p.Name, p.Age);

            }


        }
    }
}
