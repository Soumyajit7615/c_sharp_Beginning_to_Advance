﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LINQStuff
{
    class ClsEmployee
    {
        public int EmployeeCode { get; set; }
        public string EmployeeName { get; set; }
        public int? ProjectCode { get; set; }

    }
    class LinqDemo
    {

        class CULWords
        {
            public string LowerWord { get; set; }
            public string UpperWord { get; set; }
        }
        static void Main(string[] args)
        {
            //LINQWithIntArray();
            //LINQWithStringArray();
            //LINQWithCollection();
            //FirstOrDefaultMethod(null);
            //LINQWithAnonymousType();
            //LINQSorting();





        }

        private static void LINQSorting()
        {
            int[] StudentsMarks = { 69, 70, 30, 45, 71, 95, 72 };
            IEnumerable<int> Score = StudentsMarks.Where(m => m >= 70).OrderBy(m => m).ThenByDescending(m => m.ToString());
            foreach (int m in Score)
                Console.WriteLine(m);

            List<Student> studentList = new List<Student>() {
    new Student() { StudentID = 1, StudentName = "John", Age = 18 } ,
    new Student() { StudentID = 2, StudentName = "Steve",  Age = 15 },
    new Student() { StudentID = 3, StudentName = "Bill",  Age = 25 },
    new Student() { StudentID = 4, StudentName = "Ram" , Age = 20 },
    new Student() { StudentID = 5, StudentName = "Ron" , Age = 19 },
    new Student() { StudentID = 6, StudentName = "Ram" , Age = 18 },
    new Student() { StudentID = 6, StudentName = "Ram" , Age = 25 }
        };
            var thenByResult = studentList.OrderBy(s => s.StudentName).ThenBy(s => s.Age);
            foreach (Student stud in thenByResult)
            {
                Console.WriteLine(stud.StudentID + " " + stud.StudentName + " " + stud.Age);

            }

            var thenByDescResult = studentList.OrderBy(s => s.StudentName).ThenByDescending(s => s.Age);
            foreach (Student stud in thenByDescResult)
            {
                Console.WriteLine(stud.StudentID + " " + stud.StudentName + " " + stud.Age);

            }
        }

        private static void LINQWithAnonymousType()
        {
            #region Anonymous Type and Method based Query


            string[] words = { "ManGo", "aPpLe", "BaNaNa", "StrawbeRRY", "AvOcAdO" };
            Console.WriteLine("Using Class CULWords");
            var ulwords = from w in words
                          select new CULWords()
                          {
                              LowerWord = w.ToLower(),
                              UpperWord = w.ToUpper()

                          };
            foreach (CULWords w in ulwords)
            {
                Console.WriteLine(w.LowerWord + " " + w.UpperWord);
            }

            ulwords = words.Select(x => new CULWords() { LowerWord = x.ToLower(), UpperWord = x.ToUpper() });

            Console.WriteLine("LINQ with Anonymous type");

            var aulwords = from w in words
                           select new
                           {
                               LowerWord = w.ToLower(),
                               UpperWord = w.ToUpper(),
                               Count = w.Length

                           };

            foreach (var w in aulwords)
            {
                Console.WriteLine(w.LowerWord + " " + w.UpperWord + " " + w.Count);
            }

            // method()
            Console.WriteLine("\nUsing Anonymous Type and Method based Query");
            var amulwords =
                words.Select(w => new { Lower = w.ToLower(), Upper = w.ToUpper() });
            foreach (var w in amulwords)
            {
                Console.WriteLine(w.Lower + " " + w.Upper);
            }

            #endregion
        }

        private static void FirstOrDefaultMethod(int? ProjectCode)
        {


            List<ClsEmployee> Employees = new List<ClsEmployee>()
            {
                new ClsEmployee(){EmployeeCode=1001,EmployeeName="Anurag",ProjectCode=101},
                new ClsEmployee(){EmployeeCode=1002,EmployeeName="Perina",ProjectCode=102},
                new ClsEmployee(){EmployeeCode=1003,EmployeeName="Ravi",ProjectCode=null},
                new ClsEmployee(){EmployeeCode=1004,EmployeeName="Silpa",ProjectCode=null}
            };

            var result = Employees.FirstOrDefault(e => e.ProjectCode == ProjectCode);

            Console.WriteLine(result.EmployeeCode + " " + result.EmployeeName + " " + result.ProjectCode);

        }
        private static void LINQWithCollection()
        {
            List<ClsProduct> ProdList = new List<ClsProduct>()
            {
                new ClsProduct() {ProdCode=111,ProdName="Laptop",ProdPrice=15000},
                new ClsProduct() {ProdCode=222,ProdName="Printer",ProdPrice=2500},
                new ClsProduct() {ProdCode=333,ProdName="Mouse",ProdPrice=250},
                new ClsProduct() {ProdCode=444,ProdName="Hard Disk",ProdPrice=3500},
                new ClsProduct() {ProdCode=555,ProdName="Scanner",ProdPrice=3000}

            };

            //LINQ
            Console.WriteLine("By using LINQ");
            var result = from p in ProdList
                         where p.ProdPrice > 1000 && p.ProdName.ToLower().Contains("s")
                         orderby p.ProdName
                         select p;
            foreach (ClsProduct p in result)
            {
                Console.WriteLine(p.ProdCode + " " + p.ProdName + " " + p.ProdPrice);
            }
            // QUERY EXPRESSION OR LAMBDA
            Console.WriteLine("QUERY EXPRESSION OR LAMBDA");
            var lresult = ProdList.Where(x => x.ProdPrice > 1000).OrderBy(x => x.ProdName);

            foreach (var item in lresult)
            {
                Console.WriteLine(item.ProdName + " " + item.ProdCode + " " + item.ProdPrice);
            }
            //SORTING

            var rest = ProdList.OrderBy(x => x.ProdName);
        }

        private static void LINQWithStringArray()
        {
            #region LINQ WITH STRING ARRAY 

            string[] StrArray = { "Ankita", "Akshara", "Pravin", "Ajay", "Sanchaita", "Sukesh", "Swarali", "Abhee", "Jordan", "Silpa", "Ravi", "Gautam", "Sanjay", "Rakesh Kanta", "Perina", "Chavva", "Diwakar", "Arun", "Sanskriti", "Anurag" };

            Console.WriteLine("By using foreach loop:");
            foreach (string str in StrArray)
            {
                //str.StartsWith("A")
                if (str.ToLower().Contains("a"))
                {
                    Console.WriteLine(str);
                }

            }
            Console.WriteLine("By Query Expressoion | LINQ:");
            Array.Sort(StrArray);
            var result = from str in StrArray
                         orderby str.ToString() ascending
                         where str.StartsWith("S")
                         select str;
            foreach (string st in result)
            {
                Console.WriteLine(st);
            }

            //  => GOES INTO // LAMBDA
            Console.WriteLine("QUERY EXPRESSION :");
            result = StrArray.Where(s => s.ToUpper().Contains("S"));
            foreach (string st in result)
            {
                Console.WriteLine(st);
            }
            #endregion
        }
        private static void LINQWithIntArray()
        {
            #region LINQ WITH INT ARRAY 
            int[] intArr = new int[] { -1, -6, 2, 11, 4, -7, 14 };
            Console.WriteLine("NORMAL SYNTAX");
            foreach (int nm in intArr)
            {
                if (nm > 0)
                {
                    Console.WriteLine(nm);
                }
            }
            //foreach (int nm in intArr)
            //select * from intArr where nm>0
            Console.WriteLine("By Query Expressoion | LINQ:");
            var result = from i in intArr // FETCHING DATA
                         where i > 0 // PUT FILTER
                         select i;   // SELECT THE FILTERED DATA
            foreach (int nm in result)
            {
                Console.WriteLine(nm);
            }


            #endregion
        }
    }
}
