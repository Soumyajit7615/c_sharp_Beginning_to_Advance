﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DelegateConceptsStuff
{
    class Item
    {
        public int ItemID { get; set; }
        public int ItemQty { get; set; }
        public string ItemName { get; set; }
        public decimal ItemPrice { get; set; }
    }
    public delegate void StockMaintenance(int code);
    class Stock
    {
        List<Item> ProductList;
        public Stock()
        {
            ProductList = new List<Item>()
            {
                new Item(){ ItemID=1001,ItemQty=10,ItemName= "Laptop",ItemPrice=25000.00m},
                new Item(){ ItemID =1002,ItemQty=10,ItemName= "HDD",ItemPrice=4500.00m},
               new Item(){ ItemID=1003, ItemQty=10,ItemName="Speaker",ItemPrice=30000.00m}

            };
        }
        public void RemoveFromStock(int ItemCode)
        {
            Item item = ProductList.FirstOrDefault(p => p.ItemID == ItemCode);
            item.ItemQty = item.ItemQty - 1;
            Console.WriteLine($"Item remove from stock {item.ItemID} {item.ItemName} {item.ItemQty}");

        }

        public void AddtoBill(int ItemCode)
        {
            Item item = ProductList.FirstOrDefault(p => p.ItemID == ItemCode);
            Console.WriteLine($"Item readyto bill {item.ItemID} {item.ItemName} {item.ItemQty}");
        }
        public void FinalPayment(int ItemCode)
        {
            Item item = ProductList.FirstOrDefault(p => p.ItemID == ItemCode);
            Console.WriteLine($"Payment under process ,not to press back button {item.ItemID} {item.ItemName} {item.ItemQty} {item.ItemPrice}");
        }



    }
    class DelegatesInRealConcepts
    {
        static void Main(string[] args)
        {
            Stock stock = new Stock();

            StockMaintenance delstockMaintenance = new StockMaintenance(stock.RemoveFromStock);

            delstockMaintenance += stock.AddtoBill;
            delstockMaintenance += stock.FinalPayment;
            delstockMaintenance(1003);
        }
    }
}
