﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DelegateConceptsStuff
{
    public delegate void Greetings(); // prototype , signature . Delegate are reference type
    class SomeOtherclass
    {
        public void report()
        {
            Console.WriteLine("print report:");
        }

    }
    class DelegateDemo
    {
        static void Show()
        {
            Console.WriteLine("1. Hello and Welcome to CTS:");
        }
        static void Display()
        {
            Console.WriteLine("2. Here we are learning delegate:");
        }
        static void Print()
        {
            Console.WriteLine("3. Have a nice day:");
        }
        static void GreetingsOfTheDay()
        {
            Show();
            Display();
            Print();


        }

        static void Main(string[] args)
        {

            //GreetingsOfTheDay();


            // SINGLE CASTING / MOULDING 
            Greetings delgreet = new Greetings(Show);
            //delgreet();

            // When the delegate will have , single refernce of method/ function . Its known as single casting. 
            // When the delegate will have , multiple refernce of method/ function . Its known as multi casting.
            // int a=1 ; a=a+1 ; a+=1 
            ////MULTI CASTING
            delgreet += Display;
            delgreet += Print;
            // int a=1 ; a=a+1 ; a-=1 
            delgreet();
            ////DECASTING
            Console.WriteLine("After removing Display method:");
            delgreet -= Display;
            delgreet();
            Console.WriteLine("Again add Display method:");
            delgreet += Display;
            Console.WriteLine("Add someother class method :");
            SomeOtherclass someOtherclass = new SomeOtherclass();
            delgreet += someOtherclass.report;
            delgreet();




        }
    }
}
