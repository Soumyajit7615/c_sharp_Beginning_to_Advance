﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DelegateConceptsStuff
{
    class EventHandlerDemo
    {
        static void Main(string[] args)
        {

            Bank HDFC = new Bank();
            HDFC.LowBalance += HDFC_LowBalance;
            Console.WriteLine($"Current Balance : {HDFC.Balance}");
            HDFC.WithDraw = 6000;
            Console.WriteLine($"Current Balance after withdraw : {HDFC.Balance}");





        }

        private static void HDFC_LowBalance()
        {
            Console.WriteLine("Insufficient Balance:");
           
        }
    }
}
