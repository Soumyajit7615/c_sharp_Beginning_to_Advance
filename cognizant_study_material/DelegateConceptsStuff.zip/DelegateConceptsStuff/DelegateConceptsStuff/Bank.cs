﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DelegateConceptsStuff
{
    class Bank
    {
        public delegate void LowBalanceHandler();
        public event LowBalanceHandler LowBalance;
        double balance;
        public Bank()
        {
            balance = 10000d;
        }
       

     
        public double Balance
        {
            get { return balance; }
            // set { balance = value; }
        }
        public double Deposite
        {
            set
            {
                balance += value;
            }
        }
        public double WithDraw
        {
            set
            {
                if ((balance - value) >= 5000)

                    balance -= value;
                else
                    LowBalance();//Event Raise


            }

        }

    }
}
