(function Greeting() {

    var d = new Date();
    var time = d.getHours();
    if (time < 12) {
        document.write("<b>Good Morning</b>");

    }
    else if (time == 12 && d.getMinutes == 00 && d.getSeconds == 00) {

        document.write("<b>Good Noon</b>");
    }
    else if (time > 12 && time <= 15) {

        document.write("<b>Good Afternoon</b>");
    }
    else if (time > 15 && time <= 24) {

        document.write("<b>Good Evening</b>");
    }
    else {

        document.write("<b>Good Morning</b>");
    }
})()