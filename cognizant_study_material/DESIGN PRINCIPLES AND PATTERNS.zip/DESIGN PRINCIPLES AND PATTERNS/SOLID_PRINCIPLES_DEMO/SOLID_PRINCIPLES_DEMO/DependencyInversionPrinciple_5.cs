﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SOLID_PRINCIPLES_DEMO
{

    public interface IEnquiryV
    {
        double CalculateDiscount();
    }
    public interface IBuyerV
    {
        void Add();
        //void Read(); // That is not feasible way to add new method
    }
    public interface IReadV : IBuyerV
    {
        void Read();
    }
    public interface IErrorHandler
    {
        void HandleError(string err);

    }
    public class BuyerV : IBuyerV, IReadV
    {
        private IErrorHandlerV IErr;
      
        public BuyerV()
        {

        }
        public BuyerV(IErrorHandlerV Err)
        {
            IErr = Err;
        }
        private int _BuyerType;
        public int BuyerType
        {
            get { return _BuyerType; }
            set { _BuyerType = value; }
        }
        public virtual double CalculateDiscount()
        {
            return 0;
        }
       
        public virtual void Add()
        {
            try
            {
                //Adds the buyer to the database
            }
            catch (Exception ex)
            {
                IErr.HandleError(ex.ToString());
                //As per the SRP says that a class should have only one responsiblity
                //and not multiple
                //System.IO.File.WriteAllText(@"d:\Error.txt", ex.ToString());
            }
        }
        public void Read()
        {
            throw new NotImplementedException();
        }
    }
    public class GoldBuyerV : BuyerV
    {
        public override double CalculateDiscount()
        {
            return base.CalculateDiscount() + 10;
        }
    }
    public class SilverBuyerV : BuyerV
    {
        public override double CalculateDiscount()
        {
            return base.CalculateDiscount() + 5;
        }
    }
    public class EquiryBuyerV : IEnquiryV
    {
        public double CalculateDiscount()
        {
            return 2;
        }
    }
    public interface IErrorHandlerV
    {
        void HandleError(string err);
    }
    public class FileErrorHandlerV : IErrorHandlerV
    {
        public void HandleError(string err)
        {
            System.IO.File.WriteAllText(@"d:\Error.txt", err.ToString());
        }
    }
    public class EventErrorHandlerV : IErrorHandlerV
    {
        public void HandleError(string err)
        {
            System.IO.File.WriteAllText(@"d:\Error.txt", err.ToString());
        }
    }
    public class StockErrorHandlerV : IErrorHandlerV
    {
        public void HandleError(string err)
        {
            System.IO.File.WriteAllText(@"d:\Error.txt", err.ToString());
        }
    }
    class DependencyInversionPrinciple_5
    {
        static void Main(string[] args)
        {
            // 1000 of clients were using old buyer class
            IBuyerV OldClients = new BuyerV(new FileErrorHandlerV());
            OldClients.Add();
            // New clients 

            IReadV INewClients = new BuyerV(new EventErrorHandlerV());
            INewClients.Add();
            INewClients.Read();

            IReadV INewNewClients = new BuyerV(new StockErrorHandlerV());
            INewNewClients.Add();
            INewNewClients.Read();

        }
    }
}
