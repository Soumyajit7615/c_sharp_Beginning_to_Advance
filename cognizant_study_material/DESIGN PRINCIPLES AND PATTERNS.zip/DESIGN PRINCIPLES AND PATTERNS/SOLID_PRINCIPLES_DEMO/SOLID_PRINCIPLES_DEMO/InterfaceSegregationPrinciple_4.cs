﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SOLID_PRINCIPLES_DEMO
{
    public interface IEnquiry
    {
        double CalculateDiscount();
    }
    public interface IBuyer
    {
        void Add();
        //void Read(); // That is not feasible way to add new method
    }
    public interface IRead : IBuyer
    {
        void Read();
    }
    public class BuyerIV : IBuyer, IRead
    {
        private int _BuyerType;
        public int BuyerType
        {
            get { return _BuyerType; }
            set { _BuyerType = value; }
        }
        public virtual double CalculateDiscount()
        {
            return 0;
        }
        public virtual void Add()
        {
            try
            {
                //Adds the buyer to the database
            }
            catch (Exception ex)
            {
                ErrorHandlerIV obj = new ErrorHandlerIV();
                obj.HandleError(ex.ToString());
                //As per the SRP says that a class should have only one responsiblity
                //and not multiple
                //System.IO.File.WriteAllText(@"d:\Error.txt", ex.ToString());
            }
        }
        public void Read()
        {
            throw new NotImplementedException();
        }
    }
    public class GoldBuyerIV : BuyerIV
    {
        public override double CalculateDiscount()
        {
            return base.CalculateDiscount() + 10;
        }
    }
    public class SilverBuyerIV : BuyerIV
    {
        public override double CalculateDiscount()
        {
            return base.CalculateDiscount() + 5;
        }
    }
    public class EquiryBuyerIV : IEnquiry
    {
        public double CalculateDiscount()
        {
            return 2;
        }
    }
    public class ErrorHandlerIV
    {
        public void HandleError(string err)
        {
            System.IO.File.WriteAllText(@"d:\Error.txt", err.ToString());
        }
    }
    class InterfaceSegregationPrinciple_4
    {
        static void Main(string[] args)
        {
            // 1000 of clients were using old buyer class
            IBuyer OldClients = new BuyerIV();
            OldClients.Add();
            // New clients
            IRead INewClients = new BuyerIV();
            INewClients.Add();
            INewClients.Read();
        }
    }
}
