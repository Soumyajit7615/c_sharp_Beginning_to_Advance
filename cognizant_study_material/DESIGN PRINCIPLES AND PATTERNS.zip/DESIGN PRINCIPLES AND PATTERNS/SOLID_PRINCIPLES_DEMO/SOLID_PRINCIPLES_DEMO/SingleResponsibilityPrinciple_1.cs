﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SOLID_PRINCIPLES_DEMO
{
    public class Buyer
    {

        public void Add()
        {
            //S STANDS FOR SRP(Single responsibility principle)
            try
            {
                //Adds the buyer to the database
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
                ErrorHandler obj = new ErrorHandler();
                obj.HandleError(ex.ToString());
                ////As per the SRP says that a class should have only one responsiblity
                ////and not multiple
                ////System.IO.File.WriteAllText(@"d:\Error.txt", ex.ToString());
            }
        }
    }
    public class ErrorHandler
    {
        public void HandleError(string err)
        {
            System.IO.File.WriteAllText(@"d:\Error.txt", err.ToString());
        }
    }
    class SingleResponsibilityPrinciple_1
    {
        static void Main(string[] args)
        {

            Buyer buyer = new Buyer();
            buyer.Add();

        }
    }
}
