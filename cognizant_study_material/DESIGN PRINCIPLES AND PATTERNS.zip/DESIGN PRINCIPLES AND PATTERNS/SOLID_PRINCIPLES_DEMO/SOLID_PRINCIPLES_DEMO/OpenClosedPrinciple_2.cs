﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SOLID_PRINCIPLES_DEMO
{
    //O Open/closed principle
    public class BuyerII
    {
        private int _BuyerType;
        public int BuyerType
        {
            get { return _BuyerType; }
            set { _BuyerType = value; }
        }

        
        public virtual double CalculateDiscount()
        {
            return 0;
        }
        //public double CalculateDiscount()
        //{
        //    if (_BuyerType == 1)
        //    {
        //        return 10;
        //    }
        //    else
        //    {
        //        return 5;
        //    }
        //}

        public virtual void Add()
        {
            try
            {
                //Adds the buyer to the database
            }
            catch (Exception ex)
            {
                ErrorHandler obj = new ErrorHandler();
                obj.HandleError(ex.ToString());
                //As per the SRP says that a class should have only one responsiblity
                //and not multiple
                //System.IO.File.WriteAllText(@"d:\Error.txt", ex.ToString());
            }
        }
    }
    public class GoldBuyer : BuyerII
    {
        public override double CalculateDiscount()
        {
            return base.CalculateDiscount() + 10;
        }
    }
    public class SilverBuyer : BuyerII
    {
        public override double CalculateDiscount()
        {
            return base.CalculateDiscount() + 5;
        }
    }
    public class EquiryBuyer : BuyerII
    {
        public override double CalculateDiscount()
        {
            return 2;
        }
        public override void Add()
        {
            throw new NotImplementedException("For Enquiry type of buyer , not add into database");
        }
    }
    public class ErrorHandlerII
    {
        public void HandleError(string err)
        {
            System.IO.File.WriteAllText(@"d:\Error.txt", err.ToString());
        }
    }
    class OpenClosedPrinciple_2
    {
        static void Main(string[] args)
        {
            EquiryBuyer equiryBuyer = new EquiryBuyer();
            Console.WriteLine($"Discount get by Enquiry type buyer : {equiryBuyer.CalculateDiscount()}");
            try
            {
                equiryBuyer.Add();
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
              
            }
     


        }
    }
}
