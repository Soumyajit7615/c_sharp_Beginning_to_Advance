﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SOLID_PRINCIPLES_DEMO
{
    public class BuyerIII
    {
        private int _BuyerType;
        public int BuyerType
        {
            get { return _BuyerType; }
            set { _BuyerType = value; }
        }
        public virtual double CalculateDiscount()
        {
            return 0;
        }
        public virtual void Add()
        {
            try
            {
                //Adds the buyer to the database
            }
            catch (Exception ex)
            {
                ErrorHandlerIII obj = new ErrorHandlerIII();
                obj.HandleError(ex.ToString());
                //As per the SRP says that a class should have only one responsiblity
                //and not multiple
                //System.IO.File.WriteAllText(@"d:\Error.txt", ex.ToString());
            }
        }
    }
    public class GoldBuyerIII : BuyerIII
    {
        public override double CalculateDiscount()
        {
            return base.CalculateDiscount() + 10;
        }
    }
    public class SilverBuyerIII : BuyerIII
    {
        public override double CalculateDiscount()
        {
            return base.CalculateDiscount() + 5;
        }
    }
    public class EquiryBuyerIII : BuyerIII
    {
        public override double CalculateDiscount()
        {
            return 2;
        }
        public override void Add()
        {
            throw new NotImplementedException("For Enquiry type of buyer , not add into database");
        }
    }
    public class ErrorHandlerIII
    {
        public void HandleError(string err)
        {
            System.IO.File.WriteAllText(@"d:\Error.txt", err.ToString());
        }
    }
    class LiskovSubstitutionPrinciple_3
    {
        static void Main(string[] args)
        {
            List<BuyerIII> ListOfBuyers = new List<BuyerIII>();
            ListOfBuyers.Add(new GoldBuyerIII());
            ListOfBuyers.Add(new SilverBuyerIII());
            //ListOfBuyers.Add(new EquiryBuyerIII());
            //So LISKOV Principle says that the parent should easily replace the child object
            foreach (BuyerIII b in ListOfBuyers)
            {
                Console.WriteLine(b.BuyerType);
                b.Add();
            }

        }
    }
}
