﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BuilderPatternDemo
{
    class clsDirector
    {
        public clsReport MakeReport(ReportBuilder objBuilder)
        {
            objBuilder.createNewReport();
            objBuilder.setReportType();
            objBuilder.setReportHeader();
            objBuilder.setReportFooter();
            return objBuilder.getReport();
        }

    }
}
