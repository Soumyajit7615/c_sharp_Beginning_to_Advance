﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BuilderPatternDemo
{
    class BuilderPatternClient
    {
        static void Main(string[] args)
        {

            clsReport objReport;
            clsDirector objDirector = new clsDirector();

            ReportPDF objRptPdf = new ReportPDF();
            objReport = objDirector.MakeReport(objRptPdf);
            objReport.displayReport();

            ReportExcel objRptExcel = new ReportExcel();
            objReport = objDirector.MakeReport(objRptExcel);
            objReport.displayReport();


        }
    }
}
