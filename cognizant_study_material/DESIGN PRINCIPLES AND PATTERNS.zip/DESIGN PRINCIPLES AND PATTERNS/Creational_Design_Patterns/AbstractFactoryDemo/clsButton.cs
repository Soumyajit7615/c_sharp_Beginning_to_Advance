﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AbstractFactoryDemo
{
    public class clsButton : InterfaceRender
    {
        public void render()
        {
            Console.WriteLine("The Button is rendered");
        }
    }
}
