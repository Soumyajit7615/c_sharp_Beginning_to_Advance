﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AbstractFactoryDemo
{
    public abstract class clsAbstractFactory
    {
        static public InterfaceRender getUIObject(int intTypeOfObject)
        {
            if (intTypeOfObject == 1)
            {
                return clsFactoryTextBox.getTextBoxObject();
            }
            else
            {
                return clsFactoryButton.getButtonObject();
            }

        }
    }
    public class clsFactoryButton : clsAbstractFactory
    {
        static public InterfaceRender getButtonObject()
        {
            return new clsButton();
        }
    }
    public class clsFactoryTextBox : clsAbstractFactory
    {
        static public InterfaceRender getTextBoxObject()
        {
            return new clsTextBox();
        }
    }
}
