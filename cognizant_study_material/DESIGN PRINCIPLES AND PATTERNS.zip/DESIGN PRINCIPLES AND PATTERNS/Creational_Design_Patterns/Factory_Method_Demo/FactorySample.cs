﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Factory_Method_Demo
{
    class FactorySample
    {
        static void Main(string[] args)
        {
            int intInvoiceType = 0;

            IInvoice objInvoice;

            Console.WriteLine("Enter the invoice type");

            intInvoiceType = Convert.ToInt16(Console.ReadLine());

            objInvoice = clsFactoryInvoice.getInvoice(intInvoiceType);
            if (objInvoice == null)
            {
                Console.WriteLine("Invoice type is not  existing :");
            }
            else
            {
                objInvoice.print();

            }

            

            
        }
    }
}
