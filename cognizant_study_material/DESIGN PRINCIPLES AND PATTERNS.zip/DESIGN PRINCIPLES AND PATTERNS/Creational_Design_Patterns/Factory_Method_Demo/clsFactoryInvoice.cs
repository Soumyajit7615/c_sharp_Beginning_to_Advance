﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Factory_Method_Demo
{
    class clsFactoryInvoice
    {
        static public IInvoice getInvoice(int intInvoiceType)
        {
            IInvoice objinv;
            if (intInvoiceType == 1)
            {
                objinv = new clsInvoiceWithHeader();
            }
            else if (intInvoiceType == 2)
            {
                objinv = new clsInvoiceWithOutHeaders();
            }
            else
            {
                return null;
            }
            return objinv;
        }
    }
}
