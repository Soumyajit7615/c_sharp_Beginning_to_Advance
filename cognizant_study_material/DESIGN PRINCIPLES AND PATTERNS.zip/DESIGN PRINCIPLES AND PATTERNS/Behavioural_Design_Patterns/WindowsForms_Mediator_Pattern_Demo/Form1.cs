﻿using System;
using System.Windows.Forms;

namespace WindowsForms_Mediator_Pattern_Demo
{
    public partial class Form1 : Form
    {
        private clsMediator objMediator = new clsMediator();
        public Form1()
        {
            InitializeComponent();
            objMediator.Register(txtName);
            objMediator.Register(btnAdd);
            objMediator.Register(btnClear);
            objMediator.Register(lstName);
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void txtName_TextChanged(object sender, EventArgs e)
        {
            objMediator.TextChange();
        }

        private void btnAdd_Click(object sender, EventArgs e)
        {
            objMediator.ClickAddButton();
        }

        private void btnClear_Click(object sender, EventArgs e)
        {
            objMediator.ClickClearButton();
        }
    }
}
