﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsForms_Statergy_Pattern_Demo
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void BtnAdd_Click(object sender, EventArgs e)
        {
            // create the new maths object
            clsMaths objMaths = new clsMaths();
            // set number1 value and number2 value
            objMaths.intNumber1 = Convert.ToInt16(txtNum1.Text);
            objMaths.intNumber2 = Convert.ToInt16(txtNum2.Text);
            // set the statergy currently we have set it to add
            objMaths.setStatergy(new clsAddStatergy());
            // call the calculate method
            MessageBox.Show(objMaths.Calculate().ToString());
        }

        private void btnSubstraction_Click(object sender, EventArgs e)
        {
            // create the new maths object
            clsMaths objMaths = new clsMaths();
            // set number1 and number2 value
            objMaths.intNumber1 = Convert.ToInt16(txtNum1.Text);
            objMaths.intNumber2 = Convert.ToInt16(txtNum2.Text);
            // we have set the statergy to subtract
            objMaths.setStatergy(new clsSubstractStatergy());
            // call the calculate method
            MessageBox.Show(objMaths.Calculate().ToString());

        }
    }
}
