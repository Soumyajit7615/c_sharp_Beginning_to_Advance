﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WindowsForm_Command_Pattern_Demo
{
    abstract class IExecute
    {
        public string strCommand = "";
        public virtual void execute()
        {

        }
    }
}
