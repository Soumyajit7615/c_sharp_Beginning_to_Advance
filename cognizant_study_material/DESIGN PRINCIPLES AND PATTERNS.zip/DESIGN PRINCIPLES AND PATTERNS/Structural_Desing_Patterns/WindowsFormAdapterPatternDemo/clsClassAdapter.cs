﻿using System;
using System.Collections;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WindowsFormAdapterPatternDemo
{
    class clsClassAdapter : CollectionBase
    {
        public virtual void Add(string str)
        {
            List.Add(str);
        }

    }
    //class clsStack : Stack
    //{
    //    public  void Push(string str)
    //    {
    //        this.push(str);
    //    }

    //}

    class clsCollectionAdapter : clsStack
    {
        public void Add(string str)
        {
            this.push(str);
        }

    }
}
