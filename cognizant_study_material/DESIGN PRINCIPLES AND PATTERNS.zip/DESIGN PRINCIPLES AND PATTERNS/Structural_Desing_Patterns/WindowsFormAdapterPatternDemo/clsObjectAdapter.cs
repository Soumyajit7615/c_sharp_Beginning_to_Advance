﻿using System;
using System.Collections;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WindowsFormAdapterPatternDemo
{
    class clsClassObjectAdapter : CollectionBase
    {

      
        public virtual void Add(string str)
        {
            List.Add(str);
        }

    }
    class clsStack : Stack
    {
        public void push(string str)
        {
            this.push(str);
        }

    }
    class clsCollectionObjectAdapter : clsClassObjectAdapter
    {
        private clsStack objStack = new clsStack();

        public override void Add(string str)
        {
            objStack.push(str);
        }

    }
}
