﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Decorator_Design_Pattern
{
    class A
    {
        public A()
        {
            Console.WriteLine("I am class A ");
        }

    }
    class B : A
    {
        public B()
        {
            Console.WriteLine("I am class B ");
        }

    }
    class C : B 
    {
        public C()
        {
            Console.WriteLine("I am class C ");
        }

    }
    class ClsBase
    {
        public void someFunction()
        {
            Console.WriteLine("Some function");
        }
    }
    class clsChild : ClsBase
    {
        public void someMoreFunction()
        {
            Console.WriteLine("Some more function");
        }
    }
    class Program
    {
        static void Main(string[] args)
        {

            ClsBase clsBase = new ClsBase();
            clsBase.someFunction();


            clsChild clsChild = new clsChild();
            clsChild.someMoreFunction();
            Console.WriteLine("Creating instance of class c:");
            C c = new C();
            

            

        }
    }
}
