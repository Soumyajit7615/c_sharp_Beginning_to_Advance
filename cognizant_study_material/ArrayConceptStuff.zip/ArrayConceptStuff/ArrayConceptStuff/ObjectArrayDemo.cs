﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ArrayConceptStuff
{
    class Employee
    {
        public int EmpCode { get; set; }
        public string EmpName { get; set; }

        public string EmpDesg { get; set; }
        public string EmpDept { get; set; }

    }

    class ObjectArrayDemo
    {
        static void Main(string[] args)
        {
            object[] MyObjectArray = new object[5];
            MyObjectArray[0] = 12345;
            MyObjectArray[1] = "I am string";
            MyObjectArray[2] = new DateTime(2021, 11, 15);
            MyObjectArray[3] = 1234.567m;
            MyObjectArray[4] = true;
            foreach (var nm in MyObjectArray)
            {

                Console.WriteLine(nm + " " + nm.GetType());
            }

            int a = (int)MyObjectArray[0];

            Employee[] employees = new Employee[3];

            employees[0] = new Employee()
            {
                EmpCode = 12345,
                EmpName = "Abhishek Shamra",
                EmpDept = "Training",
                EmpDesg = "Trainer"

            };
            Employee[] employees2 = new Employee[3]
                {

            new Employee()
            {
                EmpCode = 12345,
                EmpName = "Abhishek Shamra",
                EmpDept = "Training",
                EmpDesg = "Trainer"

            } ,
             new Employee()
            {
                EmpCode = 12345,
                EmpName = "Abhishek Shamra",
                EmpDept = "Training",
                EmpDesg = "Trainer"

            },
              new Employee()
            {
                EmpCode = 12345,
                EmpName = "Abhishek Shamra",
                EmpDept = "Training",
                EmpDesg = "Trainer"

            }

            };





        }
    }
}
