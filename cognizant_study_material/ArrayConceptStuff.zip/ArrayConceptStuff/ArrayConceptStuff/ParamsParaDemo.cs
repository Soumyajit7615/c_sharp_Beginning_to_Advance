﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ArrayConceptStuff
{
    class ParamsParaDemo
    {
        static void Main(string[] args)
        {
            AdditionOfNumbers(3,4,1, 2, 3, 5, 45, 78, 34, 66);
        }
        private static void AdditionOfNumbers(int a,int b,params int[] k)
        {
            int tot = 0;
            Console.WriteLine("Addition Of Numbers : {0} ", a + b);
            for (int i = 0; i < k.Length; i++)
            {
                tot = tot + k[i];
            }

            Console.WriteLine("Addition Of Numbers remaining number : {0} ", tot);


        }
    }
}
