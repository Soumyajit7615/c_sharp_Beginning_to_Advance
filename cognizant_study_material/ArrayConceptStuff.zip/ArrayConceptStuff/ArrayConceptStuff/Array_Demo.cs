﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ArrayConceptStuff
{//n(n+1)/2
    class DemoClass
    {
        public int Code { get; set; }
        public string Value { get; set; }
    }
    class Array_Demo
    {
        static int AdditionOfArrayElements(int[] FormalArray)
        {
            int a = 0;
            for (int i = 0; i < FormalArray.Length; i++)
            {
                a = a + FormalArray[i];
                Console.Write(" " + FormalArray[i]);

            }
            Console.WriteLine();
            return a;
        }
        static void Main(string[] args)
        {
            // int MyArray[5] C,C++ way, Array is value type in c lang.
            //SINGLE DIMENSION ARRAY
            Console.WriteLine("Working with integer Array:");
            int[] MyIntArray = new int[5];// LHS = RHS
            //Initialization of Array
            for (int i = 0; i < MyIntArray.Length; i++)
            {
                MyIntArray[i] = i + 1;
            }
            //Displaying the elements of Array
            Console.WriteLine("Elements of integer Array : Using For");
            for (int i = 0; i < MyIntArray.Length; i++)
            {
                Console.WriteLine(MyIntArray[i]);
            }

            Console.WriteLine("By Using for each loop :");

            foreach (var nm in MyIntArray)
            {
                Console.Write(" " + nm);
            }
            Console.WriteLine();

            Console.WriteLine("DIRECT INITIALIZATION OF ARRAY");

            //LHS = RHS

            int[] MyIntArr = { 1, 2, 3, 4, 5, 6, 7, 8, 9, 10 };

            int[] MyIntArry = new int[10] { 1, 2, 3, 4, 5, 6, 7, 8, 9, 10 };

            //Object initializer
            DemoClass dc = new DemoClass()
            {
                Code = 1,
                Value = "One"

            };

            string[] NameList = new string[5];
            NameList[0] = "Abhee";
            NameList[1] = "Swara";
            NameList[2] = "Gautam";
            NameList[3] = "Ankita";
            NameList[4] = "Sanjay";

            string[] NameList2 = new string[5]
            {
            "Abhee Vasani",

            "Swara",
            "Gautam",
            "Ankita",
            "Sanjay"

        };
            string[] NameList3 =
           {

            "Abhee Vasani",
            "Abhishek SHarma",
            "Swarali Gaikwad",
            "Gautam Jain",
            "Ankita Singh",
            "Sanjay Davang"


       };
            foreach (var item in NameList3)
            {
                Console.WriteLine(item);
            }

            string words = "This is my character string";
            char[] mycharArray = words.ToCharArray();
            for (int i = 0; i < mycharArray.Length; i++)
            {
                Console.Write(mycharArray[i] + " ");

            }
            Console.WriteLine();

            foreach (string nm in NameList3)
            {
                Console.Write(nm + " : ");
                char[] name = nm.ToCharArray();
                foreach (char ch in name)
                {
                    Console.Write(ch + " ");
                }
                Console.WriteLine(" : " + nm.Length);

            }

            int[] Array100Elements = new int[100];
            for (int i = 0; i < 100; i++)
            {
                Array100Elements[i] = i + 1;

            }

            Console.WriteLine("The total is : {0}", AdditionOfArrayElements(Array100Elements));

        }
    }
}
