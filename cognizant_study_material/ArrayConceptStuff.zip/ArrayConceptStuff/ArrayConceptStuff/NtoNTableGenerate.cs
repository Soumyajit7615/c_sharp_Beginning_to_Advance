﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ArrayConceptStuff
{
    class NtoNTableGenerate
    {
        static void Main(string[] args)
        {

            int StartNo = Convert.ToInt32(args[0]), EndNo = Convert.ToInt32(args[1]);
            Console.WriteLine($"The table from {StartNo} to {EndNo}");
            //Console.Write("Enter Start No. : ");
            //StartNo = Convert.ToInt32(Console.ReadLine());
            //Console.Write("Enter End No. : ");
            //EndNo = Convert.ToInt32(Console.ReadLine());

            for (int i = StartNo; i <= EndNo; i++)
            {
                Console.WriteLine("The table of : {0} \n", i);

                for (int j = 1; j <= 10; j++)
                {
                    Console.WriteLine($"{i} X {j} = {i * j}");
                }
            }
        }
    }
}
