﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ArrayConceptStuff
{
    class CommandLineDemo
    {
        static void Main(string[] args)
        {
            //ARGV , ARGC

            Console.WriteLine("Full of Employee NAME \n FIRST NAME :{0} AND LAST NAME : {1}", args[0], args[1]);
        }
    }
}
